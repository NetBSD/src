//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Rawrite32.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_RAWRITE32_DIALOG            102
#define IDS_OPEN_IMAGE_FILTER           102
#define IDS_OPEN_IMAGE_TITLE            103
#define IDS_MESSAGE_UNCOMPRESSED        104
#define IDS_MESSAGE_COMPRESSED          105
#define IDP_DEVENUM_FAILED              106
#define IDP_ARE_YOU_SURE                107
#define IDP_NO_DISK                     108
#define IDP_WRITE_ERROR                 109
#define IDS_SUCCESS                     110
#define IDP_NO_VXD                      111
#define IDS_HOME_URL                    112
#define IDS_START_HINT                  113
#define IDP_BAD_SKIP                    114
#define IDS_HELP_URL                    115
#define IDR_MAINFRAME                   128
#define IDC_WRITE_DISK                  1000
#define IDC_IMAGE_NAME                  1001
#define IDC_BROWSE                      1002
#define IDC_OUTPUT                      1003
#define IDC_DRIVES                      1004
#define IDC_SURF_HOME                   1005
#define IDC_SECTOR_SKIP                 1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
