/foo^bar/
/foo$bar/
